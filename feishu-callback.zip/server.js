// 飞书企业自建应用回调服务（CloudRun 部署）
// 三个职责：
//   1) GET /callback  — 飞书 URL 校验（返回 challenge）
//   2) POST /callback — 卡片按钮点击事件处理
//   3) GET /healthz    — 健康检查
//
// 端口：固定 3000（ CloudBase CloudRun 默认）

const http = require('http')
const cloudbase = require('@cloudbase/node-sdk')

const PORT = process.env.PORT || 3000
const ENV_ID = process.env.ENV_ID || 'cloud1-d1giav41g83ec697e'

// 初始化 CloudBase SDK（用环境级 API Key 鉴权，无需用户登录）
let app = null
try {
  app = cloudbase.init({
    env: ENV_ID,
    // 使用环境级 API Key（从 CloudBase 控制台 → 环境 → API 访问管理拿）
    // 这里通过环境变量传入（不在源码里写死）
    secretId: process.env.TENCENTCLOUD_SECRETID,
    secretKey: process.env.TENCENTCLOUD_SECRETKEY
  })
  console.log('[CloudBase init ok] env=' + ENV_ID)
} catch (e) {
  console.error('[CloudBase init fail]', e && e.message)
}

// 状态常量
const STATUS_LABEL = {
  pending_ship: '待发送',
  shipping: '运送中',
  delivered: '已到达'
}
const STATUS_NEXT = {
  pending_ship: 'shipping',
  shipping: 'delivered'
  // delivered 终态
}

// 解析飞书 POST 回调（支持加密 + 非加密两种）
function parseFeishuEvent(rawBody) {
  let body
  try {
    body = typeof rawBody === 'string' ? JSON.parse(rawBody) : rawBody
  } catch (e) {
    return { error: 'invalid_json' }
  }

  // 如果 encrypt 字段存在 → 需要解密（需要 Encrypt Key）
  if (body.encrypt) {
    // 飞书加密模式：需要用 Encrypt Key 解密
    // 暂时不实现，等用户提供 Encrypt Key 再加
    return { error: 'encrypted_not_supported', need: 'Encrypt Key' }
  }

  return { event: body }
}

// 卡片按钮回调处理
async function handleCardAction(actionData) {
  // 飞书 card.action.trigger 回调结构：
  // { type: 'event_callback', ... event: { type: 'card.action.trigger', action: { value: {...}, tag: 'button' }, ... } }
  const event = actionData.event || {}
  const action = event.action || {}
  const value = action.value || {}

  console.log('[CARD_ACTION]', JSON.stringify({
    action: value.action,
    recordId: value.recordId,
    newStatus: value.newStatus,
    openId: event.operator && event.operator.open_id,
    userId: event.operator && event.operator.user_id
  }))

  if (value.action !== 'set_status' || !value.recordId || !value.newStatus) {
    return { ok: false, message: '无效的 action' }
  }

  // 校验：状态机只允许单向推进
  const expectedPrev = Object.keys(STATUS_NEXT).find((k) => STATUS_NEXT[k] === value.newStatus)
  if (!expectedPrev) {
    return { ok: false, message: '无效的目标状态' }
  }

  // 改 CloudBase 数据库
  try {
    if (!app) throw new Error('CloudBase 未初始化')
    const db = app.database()
    // 先读当前状态
    const cur = await db.collection('redeem_records').doc(value.recordId).get()
    const rec = cur.data && (Array.isArray(cur.data) ? cur.data[0] : cur.data)
    if (!rec) {
      return { ok: false, message: '记录不存在' }
    }
    const currentStatus = rec.status || 'pending_ship'
    // 状态机校验
    if (currentStatus !== expectedPrev) {
      return { ok: false, message: '状态机校验失败：当前 ' + STATUS_LABEL[currentStatus] + ' 不能改为 ' + STATUS_LABEL[value.newStatus] }
    }
    // 更新
    await db.collection('redeem_records').doc(value.recordId).update({
      status: value.newStatus,
      statusUpdatedAt: Date.now(),
      statusUpdatedBy: (event.operator && (event.operator.user_id || event.operator.open_id)) || 'feishu_anonymous'
    })
    return { ok: true, recordId: value.recordId, newStatus: value.newStatus, prevStatus: currentStatus }
  } catch (err) {
    console.error('[DB_UPDATE_FAIL]', err)
    return { ok: false, message: '数据库更新失败：' + (err.message || String(err)) }
  }
}

// HTTP 服务
const server = http.createServer(async (req, res) => {
  // CORS 头（保险起见，所有响应都加）
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') {
    res.writeHead(204)
    res.end()
    return
  }

  // 健康检查
  if (req.url === '/healthz' || req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ ok: true, service: 'feishu-callback', env: ENV_ID, ts: Date.now() }))
    return
  }

  // 飞书回调路径
  if (req.url === '/callback' || req.url.startsWith('/callback?')) {
    // GET: URL 校验 — 飞书发 GET 带 challenge query 参数
    if (req.method === 'GET') {
      const url = new URL(req.url, 'http://' + (req.headers.host || 'localhost'))
      const challenge = url.searchParams.get('challenge') || url.searchParams.get('challenge ')
      console.log('[URL_VERIFY]', { challenge })
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' })
      // 飞书要求返回 {"challenge": "<value>"}
      res.end(JSON.stringify({ challenge: challenge || '' }))
      return
    }

    // POST: 事件回调
    if (req.method === 'POST') {
      let raw = ''
      req.on('data', (chunk) => { raw += chunk })
      req.on('end', async () => {
        console.log('[POST_RECEIVED]', { len: raw.length, head: raw.slice(0, 200) })
        const parsed = parseFeishuEvent(raw)
        if (parsed.error === 'invalid_json') {
          res.writeHead(400, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ code: -1, msg: 'invalid_json' }))
          return
        }
        if (parsed.error === 'encrypted_not_supported') {
          res.writeHead(501, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ code: -1, msg: parsed.error, hint: parsed.need }))
          return
        }
        const event = parsed.event
        // URL 校验也通过 POST 发（飞书老协议），需要兼容
        if (event && event.type === 'url_verification') {
          console.log('[URL_VERIFY_POST]', { challenge: event.challenge })
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' })
          res.end(JSON.stringify({ challenge: event.challenge || '' }))
          return
        }
        // 卡片按钮回调
        if (event && event.type === 'card.action.trigger' || event && event.header && event.header.event_type === 'card.action.trigger') {
          const result = await handleCardAction(event)
          // 飞书回调要求返回 { code: 0, msg: 'success', data: {...} } 表示成功
          if (result.ok) {
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify({
              code: 0,
              msg: 'success',
              data: {
                // 飞书支持回写卡片更新 toast 提示
                toast: {
                  type: 'success',
                  content: '已标记为：' + STATUS_LABEL[result.newStatus]
                }
              }
            }))
          } else {
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify({
              code: 0,
              msg: 'success',
              data: {
                toast: {
                  type: 'error',
                  content: result.message
                }
              }
            }))
          }
          return
        }
        // 其它事件类型：先记录日志，返回成功（避免飞书反复重试）
        console.log('[UNHANDLED_EVENT]', { type: event && event.type, header: event && event.header })
        res.writeHead(200, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ code: 0, msg: 'success' }))
      })
      return
    }
  }

  // 未知路径
  res.writeHead(404, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ code: -1, msg: 'not_found' }))
})

server.listen(PORT, () => {
  console.log('[Server] listening on port ' + PORT)
})